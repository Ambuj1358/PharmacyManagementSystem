package com.pharma.inventoryService.repository;

import com.pharma.inventoryService.model.Drug;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DrugRepository extends JpaRepository<Drug, Long> {

    // Optional: Add custom queries if needed
    boolean existsByName(String name);
}
