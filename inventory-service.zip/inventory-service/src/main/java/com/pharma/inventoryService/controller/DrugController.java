package com.pharma.inventoryService.controller;

import com.pharma.inventoryService.dto.DrugRequest;
import com.pharma.inventoryService.dto.DrugResponse;
import com.pharma.inventoryService.service.DrugService;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/drugs")
public class DrugController {

    private final DrugService drugService;

    public DrugController(DrugService drugService) {
        this.drugService = drugService;
    }

    // 🔹 Create a new drug
    @PostMapping
    public ResponseEntity<DrugResponse> addDrug(@Valid @RequestBody DrugRequest request) {
        DrugResponse response = drugService.addDrug(request);
        return ResponseEntity.ok(response);
    }

    // 🔹 Get all drugs
    @GetMapping
    public ResponseEntity<List<DrugResponse>> getAllDrugs() {
        return ResponseEntity.ok(drugService.getAllDrugs());
    }

    // 🔹 Get drug by ID
    @GetMapping("/{id}")
    public ResponseEntity<DrugResponse> getDrugById(@PathVariable Long id) {
        return ResponseEntity.ok(drugService.getDrugById(id));
    }

    // 🔹 Update drug
    @PutMapping("/{id}")
    public ResponseEntity<DrugResponse> updateDrug(
            @PathVariable Long id,
            @Valid @RequestBody DrugRequest request) {
        DrugResponse updated = drugService.updateDrug(id, request);
        return ResponseEntity.ok(updated);
    }

    // 🔹 Delete drug
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteDrug(@PathVariable Long id) {
        drugService.deleteDrug(id);
        return ResponseEntity.ok("Drug deleted successfully");
    }
}
