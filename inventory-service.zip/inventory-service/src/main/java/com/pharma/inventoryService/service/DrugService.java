package com.pharma.inventoryService.service;

import com.pharma.inventoryService.dto.DrugRequest;
import com.pharma.inventoryService.dto.DrugResponse;
import com.pharma.inventoryService.exception.ResourceNotFoundException;
import com.pharma.inventoryService.model.Drug;
import com.pharma.inventoryService.repository.DrugRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DrugService {

    private final DrugRepository drugRepository;

    //Constructor
    public DrugService(DrugRepository drugRepository) {
        this.drugRepository = drugRepository;
    }

    //Add a new drug
    public DrugResponse addDrug(DrugRequest request) {
        Drug drug = new Drug();
        drug.setName(request.getName());
        drug.setDescription(request.getDescription());
        drug.setPrice(request.getPrice());
        drug.setQuantity(request.getQuantity());
        drug.setSupplier(request.getSupplier());
        drug.setCreatedAt(LocalDateTime.now());

        Drug saved = drugRepository.save(drug);
        return mapToResponse(saved);
    }

    // 🔹 Get all drugs
    public List<DrugResponse> getAllDrugs() {
        return drugRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    // Get drug by ID
    public DrugResponse getDrugById(Long id) {
        Drug drug = drugRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Drug not found with ID: " + id));
        return mapToResponse(drug);
    }

    //Update existing drug
    public DrugResponse updateDrug(Long id, DrugRequest request) {
        Drug drug = drugRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Drug not found with ID: " + id));

        drug.setName(request.getName());
        drug.setDescription(request.getDescription());
        drug.setPrice(request.getPrice());
        drug.setQuantity(request.getQuantity());
        drug.setSupplier(request.getSupplier());

        Drug updated = drugRepository.save(drug);
        return mapToResponse(updated);
    }

    //Delete drug by ID
    public void deleteDrug(Long id) {
        if (!drugRepository.existsById(id)) {
            throw new ResourceNotFoundException("Drug not found with ID: " + id);
        }
        drugRepository.deleteById(id);
    }

    //Convert Entity to DTO
    private DrugResponse mapToResponse(Drug drug) {
        DrugResponse response = new DrugResponse();
        response.setId(drug.getId());
        response.setName(drug.getName());
        response.setDescription(drug.getDescription());
        response.setPrice(drug.getPrice());
        response.setQuantity(drug.getQuantity());
        response.setSupplier(drug.getSupplier());
        response.setCreatedAt(drug.getCreatedAt());
        return response;
    }
}
