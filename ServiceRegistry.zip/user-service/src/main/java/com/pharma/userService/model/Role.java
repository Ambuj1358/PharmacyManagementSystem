package com.pharma.userService.model;

public enum Role {
      ADMIN,
      DOCTOR
}
