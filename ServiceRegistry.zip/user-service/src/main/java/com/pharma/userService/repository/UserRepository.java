package com.pharma.userService.repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pharma.userService.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
    
    // For login/authentication
    Optional<User> findByEmail(String email);
    
    // For checking if user already exists
    boolean existsByEmail(String email);
}
