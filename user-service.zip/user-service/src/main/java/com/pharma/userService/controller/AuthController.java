package com.pharma.userService.controller;

import com.pharma.userService.dto.JwtResponse;
import com.pharma.userService.dto.LoginRequest;
import com.pharma.userService.dto.RegisterRequest;
import com.pharma.userService.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class AuthController {

    private final UserService userService;
    
    

    public AuthController(UserService userService) {
		super();
		this.userService = userService;
	}

	// Public - Registration
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody @Valid RegisterRequest request) {
        String response = userService.registerUser(request);
        return ResponseEntity.ok(response);
    }

    // Public - Login
    @PostMapping("/login")
    public ResponseEntity<JwtResponse> login(@RequestBody @Valid LoginRequest request) {
        JwtResponse jwt = userService.authenticate(request);
        return ResponseEntity.ok(jwt);
    }

    // Secured endpoint example
    @GetMapping("/me")
    public ResponseEntity<String> securedTest() {
        return ResponseEntity.ok("You are authenticated!");
    }
}
