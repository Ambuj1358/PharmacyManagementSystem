package com.pharma.orderService.service;

import com.pharma.orderService.dto.OrderRequest;
import com.pharma.orderService.dto.OrderResponse;
import com.pharma.orderService.exception.ResourceNotFoundException;
import com.pharma.orderService.model.Order;
import com.pharma.orderService.repository.OrderRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {

    private final OrderRepository orderRepository;

    // ✅ Constructor injection (no @RequiredArgsConstructor)
    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public OrderResponse placeOrder(OrderRequest request) {
        Order order = new Order();
        order.setUserEmail(request.getUserEmail());
        order.setMedicineName(request.getMedicineName());
        order.setQuantity(request.getQuantity());
        order.setPrice(request.getPrice());
        order.setStatus("PENDING");
        order.setCreatedAt(LocalDateTime.now());

        Order saved = orderRepository.save(order);

        return mapToResponse(saved);
    }

    public List<OrderResponse> getOrdersByUser(String email) {
        List<Order> orders = orderRepository.findByUserEmail(email);
        List<OrderResponse> responses = new ArrayList<>();
        for (Order order : orders) {
            responses.add(mapToResponse(order));
        }
        return responses;
    }

    public OrderResponse getOrderById(Long id) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with ID: " + id));
        return mapToResponse(order);
    }
    
    public OrderResponse updateOrderStatus(Long id, String newStatus) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with ID: " + id));

        order.setStatus(newStatus);  // Example: "CONFIRMED"
        Order updatedOrder = orderRepository.save(order);

        return mapToResponse(updatedOrder);
    }


    private OrderResponse mapToResponse(Order order) {
        OrderResponse response = new OrderResponse();
        response.setId(order.getId());
        response.setUserEmail(order.getUserEmail());
        response.setMedicineName(order.getMedicineName());
        response.setQuantity(order.getQuantity());
        response.setPrice(order.getPrice());
        response.setStatus(order.getStatus());
        response.setCreatedAt(order.getCreatedAt());
        return response;
    }
}
