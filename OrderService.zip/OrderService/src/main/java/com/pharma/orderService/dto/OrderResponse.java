package com.pharma.orderService.dto;

import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderResponse {

    private Long id;
    private String userEmail;
    private String medicineName;
    private Integer quantity;
    private Double price;
    private String status;
    private LocalDateTime createdAt;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getMedicineName() {
		return medicineName;
	}
	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	public OrderResponse(Long id, String userEmail, String medicineName, Integer quantity, Double price, String status,
			LocalDateTime createdAt) {
		super();
		this.id = id;
		this.userEmail = userEmail;
		this.medicineName = medicineName;
		this.quantity = quantity;
		this.price = price;
		this.status = status;
		this.createdAt = createdAt;
	}
	public OrderResponse() {
		super();
	}
    
    
    
}
