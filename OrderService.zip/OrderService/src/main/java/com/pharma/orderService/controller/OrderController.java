package com.pharma.orderService.controller;

import com.pharma.orderService.dto.OrderRequest;
import com.pharma.orderService.dto.OrderResponse;
import com.pharma.orderService.service.OrderService;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService orderService;

   
    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    //Place a new order
    @PostMapping
    public ResponseEntity<OrderResponse> placeOrder(@Valid @RequestBody OrderRequest request) {
        OrderResponse response = orderService.placeOrder(request);
        return ResponseEntity.ok(response);
    }

    //Get all orders by user (doctor)
    @GetMapping("/user/{email}")
    public ResponseEntity<List<OrderResponse>> getOrdersByUser(@PathVariable String email) {
        List<OrderResponse> responses = orderService.getOrdersByUser(email);
        return ResponseEntity.ok(responses);
    }

    //Get specific order by ID
    @GetMapping("/{id}")
    public ResponseEntity<OrderResponse> getOrderById(@PathVariable Long id) {
        OrderResponse response = orderService.getOrderById(id);
        return ResponseEntity.ok(response);
    }
    
 // Update status of an order (e.g., PENDING → CONFIRMED)
    @PutMapping("/{id}/status")
    public ResponseEntity<OrderResponse> updateOrderStatus(
            @PathVariable Long id,
            @RequestParam String value) {

        OrderResponse updated = orderService.updateOrderStatus(id, value);
        return ResponseEntity.ok(updated);
    }

}

